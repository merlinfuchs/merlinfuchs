# Handoff: merlin's desk — personal site (5 pages)

## Overview
A personal site for Merlin Fuchs (merlin.onl / merlin.gg), built on one metaphor: **a desk with four drawers**. The home page is the desk surface; each drawer is a topic page (Software, Photography, Tinkering, Cycling). The aesthetic is analogue-office: dotted desk paper, ruled note cards, hard offset ink shadows, sticky notes, receipts, photo prints — with real interaction rather than decoration.

Five pages:

| File | Page |
| --- | --- |
| `home.dc.html` | The desk (home) |
| `software.dc.html` | Drawer 1 — Software |
| `photography.dc.html` | Drawer 2 — Photography |
| `tinkering.dc.html` | Drawer 3 — Tinkering |
| `cycling.dc.html` | Drawer 4 — Cycling |

## About the Design Files
The `.dc.html` files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior. They are not production code to lift directly. They render through a small runtime (`support.js`) that turns the markup between `<x-dc>` tags into React; all styling is inline on the elements, which is a constraint of the prototyping environment, **not** a recommendation for the real implementation.

The task is to **recreate these designs in the target codebase's existing environment** (React/Next, Astro, Svelte, plain HTML+CSS, etc.) using its established patterns — components, a stylesheet or CSS modules/Tailwind, and its routing. If no codebase exists yet, pick a framework suited to a static personal site (Astro or Next static export are both good fits) and implement there.

To view a prototype: open the `.dc.html` file in a browser with `support.js` sitting next to it.

## Fidelity
**High fidelity.** Colors, type, spacing, shadows and copy are final-intent. Recreate pixel-closely, but re-express the styling in the codebase's normal system (classes/tokens instead of inline styles). Placeholder imagery (striped boxes labelled "photo — …") is intentional: real photos go there.

## Design Tokens

### Color
| Token | Hex | Use |
| --- | --- | --- |
| desk | `#e8e2d4` | page background (with dot pattern) |
| ink | `#2b2620` | text, all borders, hard shadows |
| ink-muted | `#6b6355` | secondary text, meta labels |
| ink-faint | `#8a8172` | tertiary text on paper |
| paper | `#fffdf6` | primary card background |
| paper-warm | `#fdf7e6` | receipts / ticket props |
| night | `#221d17` | dark CTA cards |
| terminal | `#0f1116` / `#1b1f27` | code window body / titlebar |
| filmstrip | `#1c1a17` | film strip props, contact sheet |
| yellow | `#ffe066` | sticky notes, "now" pad |
| yellow-deep | `#ffd94a` | CTA buttons on dark cards, pad sheets |
| link | `#1d4f8f` | links |
| link-hover-fg / bg | `#c2410c` / `#ffe9a8` | link hover (highlighter effect) |
| drawer-software | `#e3ddc8` | Software drawer tab/card |
| drawer-photography | `#dfe3e8` | Photography |
| drawer-tinkering | `#dee4de` | Tinkering |
| drawer-cycling | `#ecdfd6` | Cycling |

Drawer colors are deliberately **desaturated** — muted toward the desk tone, not candy-colored.

### Desk background
```css
background: #e8e2d4;
background-image: radial-gradient(circle at 1px 1px, rgba(60,50,35,.16) 1px, transparent 1.6px);
background-size: 22px 22px;
```

### Typography
- **Display / headings:** `'Instrument Serif', Georgia, serif` — weight 400 only; italic variant used for section headers and accents. Sizes: 64px (home wordmark), 46px (drawer page H1), 34px (home intro H1), 27–29px (card titles / section headers), 23px (prev-next nav).
- **Body / UI:** `'Space Mono', monospace` — 13px body, 12px card body, 11px meta, 10px uppercase labels with `letter-spacing:.06–.16em`.
- **Handwriting:** `'Caveat', cursive` — 17–26px, used for captions, sticky notes, the tagline "A lot of stuff here. Some of it even works."
- Body line-height 1.8–1.85; text-wrap: pretty on paragraphs.
- Google Fonts: `Caveat:wght@500;700`, `Instrument+Serif:ital@0;1`, `Space+Mono:wght@400;700`.

### Borders, shadows, radius
- Card border: `2px solid #2b2620` (nav chips and prop cards use 1px, often in a lighter tone like `#d9cfb2`).
- Hard offset shadow (the signature): `5px 5px 0 #2b2620` on drawer cards, `6px 6px 0 rgba(43,38,32,.85)` on the large paper cards, `3px 3px 0 #2b2620` on small buttons.
- Soft shadow for loose objects (photos, film strips, sticky notes): `0 6px 14px rgba(0,0,0,.18)` — heavier variants up to `0 10px 22px rgba(0,0,0,.32)` for dark objects.
- Radius: **0 everywhere** except circles (`50%` on window dots).
- Dashed rules inside cards: `1px dashed rgba(43,38,32,.45)`; dashed page rules use `repeating-linear-gradient(90deg,#2b2620 0 10px,transparent 10px 18px)` at 2px tall.
- Ruled-paper fill on big cards: `repeating-linear-gradient(180deg,transparent 0 27px,rgba(60,80,140,.14) 27px 28px)`.

### Rotation
Almost every card is rotated between `-1.8deg` and `+1.5deg`. Use small, varied values — nothing is perfectly square, but nothing is more than ~2°.

### Layout
- Page padding: home `56px 28px 96px`; drawer pages `52px 40px 104px`.
- Content column: `max-width: 1080px`, centered, `position: relative`.
- Content grid: `display:grid; grid-template-columns:repeat(12,1fr); gap:46px 26px; align-items:start` (home uses `38px 28px`). Cards claim spans like `1 / span 8`, `9 / span 4`, `1 / -1`.
- Card interior padding: 22–34px.

## Background props (all five pages)
Each page has an absolutely-positioned prop layer **behind** the content grid:

```
prop layer:  position:absolute; inset:-26px -300px (home: -30px -300px);
             z-index:0; overflow:hidden; pointer-events:none;
             filter: saturate(.42) contrast(.94) opacity(.9);
content grid: position:relative; z-index:2
nav + footer: position:relative; z-index:3
```

Props are positioned so that **most of each object is hidden behind the opaque content cards** and only an edge or corner shows in the page margins. Offsets are given relative to the prop layer (which extends 300px past the content column on each side), so e.g. `left:186px` puts an object 114px outside the content column. They are desaturated by the layer filter so they read as background.

Props by page:
- **home** — two photo prints (workshop, a ride), a film strip, an "ADMIT ONE" ticket, a letter with a stamp box, a failed-print photo.
- **software** — a paid invoice slip, an unfocused terminal window (grey traffic lights), a yellow "ship it friday? no. monday." sticky, a business card.
- **photography** — a spare photo print, a film strip, a "DEV TIMES · C-41" note, a negative sleeve.
- **tinkering** — a graph-paper bracket sketch, a filament spool (thick-bordered circle), a perfboard, a parts bag.
- **cycling** — a map sheet with a route line, an elevation profile bar chart, race bib "247", a kit sticky note.

An earlier iteration put a frosted "desk pad" (semi-transparent sheet with `backdrop-filter`) over these props. It was removed — do **not** reintroduce it. `software - with pad.dc.html` in the project shows that discarded direction if you want the history.

## Screens

### 1. Home — `home.dc.html`
**Purpose:** orient a visitor in ten seconds and send them into one of four drawers.

Top to bottom:
1. **Masthead** (flex, space-between, wraps). Left: wordmark "merlin's *desk*" — 64px Instrument Serif, the word "desk" italic in `#c2410c`, block rotated `-1.2deg`; beneath it the Caveat tagline at 22px. Right: a black chip `GERMANY · 23 · FOUR DRAWERS, ONE DESK` (ink bg, `#e8e2d4` text, 11px, rotated 1deg) and a yellow mail button (`#ffd94a`, 2px ink border, `3px 3px 0` ink shadow, rotated -1deg).
2. **Intro card** (`1 / span 8`, rotated -0.7deg): ruled paper card with a piece of tape (semi-transparent yellow rectangle) crossing its top-left corner. Inside, a 118px taped photo placeholder ("a photo of me", 100×100) with a Caveat "hi 👋" caption, beside an H1 "Hi, I'm Merlin!" (34px) and three body paragraphs.
3. **"What I'm doing now" pad** (`9 / span 4`, rotated 1.5deg) — **interactive, the centerpiece**. A stack of four yellow sheets, each with a Caveat title, four `→` lines, a date and a tear control. Behaviour:
   - Top sheet is draggable by mouse: `mousedown` captures the pointer, `mousemove` translates the sheet, `mouseup` beyond a 46px threshold tears it off; a shorter drag springs it back.
   - Tearing animates the sheet away (translate along the drag direction ×280px extra + rotation + fade, 520ms `cubic-bezier(.3,.9,.3,1)`) and reveals the next sheet.
   - Sheets below are offset 3px/3px per depth with `-0.8deg` per depth of rotation, and a lighter shadow.
   - The last sheet cannot be torn (label reads "last sheet").
   - A "↺ new pad, please" button under the stack restacks all four.
   - Sheet content (title / date / lines) is data: "what i'm doing now · THIS WEEK", "last week · JUL 2026", "the month before · JUN 2026", "a while ago · SPRING 2026".
4. **Section header** "the four drawers" — italic Instrument Serif 27px, dashed rule filling remaining width, "pick one" at right.
5. **Four drawer cards** (2×2, each `span 6`, tilts -0.9/1.1/1.2/-1deg). Each is an `<a>` with: a small drawer-tab rectangle protruding above the top edge (104×16px, same fill, ink border, no bottom border), the drawer color as background, `5px 5px 0 #2b2620`, a 27px serif title, a 12px description, and a footer row `NEWEST: <thing>` / `OPEN →` above a dashed rule. Hover: lift/scale via `transform` transition `.26s cubic-bezier(.2,.9,.3,1.2)`.
6. **Receipt card** (`1 / span 7`, rotated 0.8deg): white paper with a torn bottom edge via `clip-path: polygon(0 0,100% 0,100% 96%,92% 100%,78% 96%,62% 100%,46% 96%,30% 100%,14% 96%,0 100%)`. Centered header "LATEST FROM EVERY DRAWER" + `merlin.onl/posts · no paywall, no popup`, then four post rows (title link left, category right), then a footer row "read the rest »" / "TOTAL: 4 SHOWN".
7. **Dark archive card** (`8 / span 5`, rotated -1.4deg, stretches to row height): `#221d17` bg, Caveat 26px heading in `#ffd94a`, body in `#d8d0c2`, and a full-width yellow button "read the archive →" pinned to the bottom with `margin-top:auto`.
8. **"elsewhere on the internet" strip** (`1 / -1`): translucent paper, 1px dashed `#8a8172` border, four external links in a wrapping flex row with `gap:16px 30px`.
9. **Footer**: centered, 11px, "made by hand ·" + the Caveat tagline + copyright.

**Known duplication:** "read the rest »" (receipt) and "read the archive →" (dark card) both link to `posts.html`. Pick one destination or differentiate them when implementing.

### 2–5. Drawer pages — `software`, `photography`, `tinkering`, `cycling`
All four share one skeleton:

1. **Nav row** (z-index 3): left, a "← back to the desk" paper button (2px ink border, `3px 3px 0` shadow, rotated -1.4deg); right, "drawer N of 4" plus chips linking to the other three drawers (1px ink border, filled with that drawer's color, 4px 9px padding).
2. **Header** (rotated -0.4deg): an inline **folder tab** — the drawer color, 2px ink border with `border-bottom:none`, 6px 15px padding, 10px uppercase label (`DRAWER ONE — THE ONE THAT PAYS FOR THE OTHERS`, etc.), `margin-left:8px` — sitting directly on a `border-top:2px solid #2b2620` rule. Below the rule: H1 46px Instrument Serif, then one line of intro (13px, `max-width:60ch`, `margin:12px 0 0`). This replaced a full-width tinted banner; keep it compact — the tab does the labelling work.
3. **Page-specific content** in the 12-column grid (see below).
4. **Prev/next drawer** (`1 / -1`, two cards side by side, gap 20px, margin-top 30px): each filled with the target drawer's color, 2px ink border, `5px 5px 0` shadow, tilted ±1deg, with a 10px label (`← PREVIOUS DRAWER` / `NEXT DRAWER →`) and a 23px serif name. The next-drawer card is right-aligned.
5. **Footer**: centered 11px line, page-specific phrase ("shot, developed and scanned by hand", "shipped, patched and occasionally reverted by hand", …) + the Caveat tagline + copyright.

Page-specific blocks:
- **Software** — a dark "code window" card (`1 / span 8`): `#1b1f27` titlebar with three **grey** dots (`#4a505c` — deliberately unfocused, not red/yellow/green) and `~/projects — currently running`; body `#0f1116` listing Kite / Xenon / Embed Generator, each with a colored left rule, a serif title, a description and a status tag (`NEWEST`, `RUNNING`); footer line "3 running · 1 in progress · 0 on fire (today)" + "all the code »". Beside it a yellow "what I reach for" sticky (Go / TypeScript+React / Postgres / Rust) and a "THE DAY JOB · PART-TIME" ruled card about Friendly Captcha. Below, a "how it actually goes" section with two ruled essay cards, a dark "hiring me?" CTA, a "WRITING FROM THIS DRAWER" receipt and an "open source and odds and ends" card.
- **Photography** — a **contact sheet** card (`1 / span 8`): `#1c1a17` panel, header `CONTACT SHEET — ROLL 041` / `PORTRA 400 · JULY 2026`, a 4-column grid of 12 frames (each `aspect-ratio:3/2`, striped fill, a caption in `#9a9484`, a frame number like `01A` in amber `#e0b45a` bottom-left), footer "drop your scans onto any frame" / "every roll so far »". Beside it a yellow "in the bag" sticky and a "DEVELOPING LOG" receipt (roll 041 drying / 040 scanned / 039 printed / 038 lost, sadly). Then "prints on the wall": one large 4:5 taped print with a Caveat caption and two smaller ones (3:2 print + a film strip). Then a ruled "Why film, in 2026" essay card and a dark "want a print?" CTA.
- **Tinkering** — bench/build cards on graph-paper backgrounds (`linear-gradient` grid at `rgba(90,120,95,.16)`), a print queue / parts list, build logs, plus the shared skeleton.
- **Cycling** — a "RIDE LOG — 2026" table card (dark header row, columns DATE / ROUTE / DIST / MOOD with `★` mood ratings), a taped bike photo, route/scraping-project cards, plus the shared skeleton.

## Interactions & Behavior
- **Now-pad tear-off** (home) — the only stateful component. State: `torn` (count), `tearing` (index mid-flight), `tearDrag` ({x,y}), plus a mouse-capture ref. Global `mousemove`/`mouseup` listeners are attached on mount and removed on unmount. Drag threshold 46px; fly-out 620ms; transitions disabled while dragging (`transition:none`) and re-enabled for the animation. Provide a non-drag affordance too (the "drag me off ✂" text is also clickable) and a keyboard/reduced-motion path in production.
- **Card hover** — drawer cards transition `transform` over `.26s cubic-bezier(.2,.9,.3,1.2)`; other cards are static.
- **Links** — default `#1d4f8f` underlined with 2px offset; hover switches to `#c2410c` with a `#ffe9a8` background, like a highlighter. Applies site-wide.
- **Navigation** — plain page-to-page links: home → four drawer pages; each drawer page back to home and sideways to the other three; `posts.html` / `rolls.html` are referenced but not designed yet.
- **Responsive** — the prototypes are desktop-first at ~1080px. Below ~900px: collapse the 12-column grid to one column, drop or reduce rotations, and hide the background prop layer entirely (it depends on wide margins). Mobile drafts exist in the project (`home-mobile.dc.html`, `software-mobile.dc.html`) if you want that direction.
- **Reduced motion** — respect `prefers-reduced-motion`: disable the tear animation (tear becomes an instant swap) and card hover transforms.

## State Management
Only the home page needs state: the now-pad (`torn`, `tearing`, `tearDrag`, plus transient drag origin). Everything else is static content. Content that clearly wants to be data rather than markup: the four drawer definitions (title, color, blurb, newest item, href), the now-pad sheets, the post list, and per-page lists (projects, contact-sheet frames, ride log rows, developing log).

## Assets
No real images — every image is a **striped placeholder**: `repeating-linear-gradient(45deg,#ded9c9 0 9px,#e9e5d7 9px 18px)` (dark variants use `#4a4a3f`/`#3a3a32`) with a monospace label describing what belongs there ("photo — the workshop", "a photo of me / 100 × 100", "wide print — a street, evening"). Replace with real photography at the same aspect ratios. Fonts come from Google Fonts. No icons or SVG artwork; the few glyphs used are text characters (`→ ✂ ↺ ✉ ★ №`).

## Files
- `home.dc.html` — the desk
- `software.dc.html` — drawer 1
- `photography.dc.html` — drawer 2
- `tinkering.dc.html` — drawer 3
- `cycling.dc.html` — drawer 4
- `support.js` — the prototyping runtime needed to open the files locally; not part of the design

Also in the project (not bundled): `software - with pad.dc.html` (discarded frosted-pad direction), `merlin's desk - clean.dc.html` and `merlin's desk - middle.dc.html` (calmer explorations of the home page), `home-mobile.dc.html` and `software-mobile.dc.html` (mobile drafts), and several period-styled experiments (`merlin.gg 1994/1999/2001/2004`, `Merlin XP`, `Merlin 2000`).
